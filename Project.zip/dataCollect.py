import tweepy
import csv

CONSUMER_KEY    = 'oGOnF3LcGOyCbNBv7dT82UrZd'
CONSUMER_SECRET = 'nFvdmVroGkA8CLi9AKaCkHPpfFswUSpNBJvvTsswHyHsjXc9AM'
# Access:
ACCESS_TOKEN  = '1179100250675412993-srmwhhtm7uIYQGL3SMxx5uHV8c3fgC'
ACCESS_SECRET = 'QrhsOsfGzGZMXbZgx2HYEHN0BADOgzFXOgcVyLVB84FYU'

auth = tweepy.OAuthHandler(CONSUMER_KEY, CONSUMER_SECRET)
auth.set_access_token(ACCESS_TOKEN, ACCESS_SECRET)
api = tweepy.API(auth)

# Open/Create a file to append data
csvFile = open('tweets.csv', 'a', newline='')

# Use csv Writer
csvWriter = csv.writer(csvFile)


for tweet in tweepy.Cursor(api.search, q="#2020Election", lang="en",
                           since="2020-09-01", until="2020-11-3 22:19").items():
    # print(tweet.created_at, tweet.text)
    csvWriter.writerow([tweet.text.encode('utf-8'),
                        len(tweet.text),
                        tweet.id,
                        tweet.created_at,
                        tweet.source,
                        tweet.favorite_count,
                        tweet.retweet_count])
