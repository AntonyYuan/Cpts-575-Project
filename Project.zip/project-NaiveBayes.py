import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from textblob import TextBlob
from nltk.stem.porter import *
from sklearn.utils import shuffle


# ------------------------------- pre-processing data -----------------------------------------------------------------

col = ['tweet', 'len', 'id', 'created_at', 'source', 'favorite_count', 'retweet_count']
data1 = pd.read_csv("tweets1.csv", sep=',', encoding='utf-8', names=col)
data2 = pd.read_csv("tweets2.csv", sep=',', encoding='utf-8', names=col)
data = pd.concat([data1, data2], axis=0)
print(data.head())


def remove_pattern(input_txt, pattern):
    r = re.findall(pattern, input_txt)
    for i in r:
        input_txt = re.sub(i, '', input_txt)
    return input_txt


# drop duplicates
data = data.drop_duplicates('tweet', 'first')
data = data.reset_index(drop=True)
print(data.shape)

# remove twitter handles (@user)
data['tidy_tweet'] = np.vectorize(remove_pattern)(data['tweet'], "@[\w]*")
print(data.head())

# remove special characters, numbers, punctuations
data['tidy_tweet'] = data['tidy_tweet'].str.replace("[^a-zA-Z#]", " ")
print(data.head())

# remove short word
data['tidy_tweet'] = data['tidy_tweet'].apply(lambda x: ' '.join([w for w in x.split() if len(w)>3]))
print(data.head())

# tokenize data
tokenized_tweet = data['tidy_tweet'].apply(lambda x: x.split())
print(tokenized_tweet.head())

# stemming
stemmer = PorterStemmer()
tokenized_tweet = tokenized_tweet.apply(lambda x: [stemmer.stem(i) for i in x])
for i in range(len(tokenized_tweet)):
    tokenized_tweet[i] = ' '.join(tokenized_tweet[i])

data['tidy_tweet'] = tokenized_tweet
print(tokenized_tweet.head())
print(len(tokenized_tweet))

'''
# ----------------------------------------- word cloud -----------------------------------------------------------------

from wordcloud import WordCloud

all_words = ' '.join([text for text in data['tidy_tweet']])
wordcloud = WordCloud(width=800, height=500, random_state=21, max_font_size=110).generate(all_words)
plt.figure(figsize=(10, 7))
plt.imshow(wordcloud, interpolation="bilinear")
plt.axis('off')
plt.show()
'''

# ----------------------------------------- labeling data -------------------------------------------------------------
def clean_tweet(tweet):
    return ' '.join(re.sub("(@[A-Za-z0-9]+)|([^0-9A-Za-z \t])|(\w+:\/\/\S+)", " ", tweet).split())


def analyze_sentiment(tweet):
    analysis = TextBlob(clean_tweet(tweet))
    if analysis.sentiment.polarity > 0:
        return 1
    elif analysis.sentiment.polarity == 0:
        return 0
    else:
        return -1


data['SA'] = np.array([analyze_sentiment(tweet) for tweet in data['tidy_tweet']])
print(data.head(10))

pos = [tweet for index, tweet in enumerate(data['tidy_tweet']) if data['SA'][index] > 0]
neu = [tweet for index, tweet in enumerate(data['tidy_tweet']) if data['SA'][index] == 0]
neg = [tweet for index, tweet in enumerate(data['tidy_tweet']) if data['SA'][index] < 0]

print("Percentage of positive tweets: {}%".format(len(pos)*100/len(data['tidy_tweet'])))
print("Percentage of neutral tweets: {}%".format(len(neu)*100/len(data['tidy_tweet'])))
print("Percentage de negative tweets: {}%".format(len(neg)*100/len(data['tidy_tweet'])))


# ------------------------------------ Create training and testing data ------------------------------------------------
# over-sampling
train_neg = neg[:int(len(neg)*0.8)]
test_neg = neg[int(len(neg)*0.8):]
train_neg = [val for val in train_neg for i in range(5)]
test_neg = [val for val in test_neg for i in range(5)]
total = len(pos) + len(neu) + len(neg)

print("Percentage of positive tweets: {}%".format(len(pos)*100/total))
print("Percentage of neutral tweets: {}%".format(len(neu)*100/total))
print("Percentage de negative tweets: {}%".format((len(train_neg)+len(test_neg))*100/total))

train_x = pos[:int(len(pos)*0.8)] + neu[:int(len(neu)*0.8)] + train_neg
train_y = [1]*int(len(pos)*0.8) + [0]*int(len(neu)*0.8) + [-1]*len(train_neg)
test_x = pos[int(len(pos)*0.8):] + neu[int(len(neu)*0.8):] + test_neg
test_y = [1]*(len(pos)-int(len(pos)*0.8)) + [0]*(len(neu)-int(len(neu)*0.8)) + [-1]*len(test_neg)

train = {'text': train_x, 'label': train_y}
test = {'text': test_x, 'label': test_y}

dtrain = pd.DataFrame(data=train)
dtest = pd.DataFrame(data=test)
dtrain = shuffle(dtrain)
dtest = shuffle(dtest)
print(dtrain.head(10))
print("\n")
print(dtest.head(10))
# -------------------------------------------- Naive Bayesian ----------------------------------------------------------

from sklearn.datasets import load_files
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix

# train
vectorizer = TfidfVectorizer(max_df=0.90, min_df=2, max_features=1000, stop_words='english')
X_train = vectorizer.fit_transform(dtrain['text'])
print("n_samples: %d, n_features: %d" % X_train.shape)
y_train = dtrain['label']
clf = MultinomialNB(alpha=0.0001)
clf.fit(X_train, y_train)
train_score = clf.score(X_train, y_train)
print("train score: {0}".format(train_score))

# test
X_test = vectorizer.transform(dtest['text'])
y_test = dtest['label']
pred = clf.predict(X_test)
print("classification report on test set for classifier:")
print(clf)
print(classification_report(y_test, pred))

# confusion matrix
cm = confusion_matrix(y_test, pred)
print("confusion matrix:")
print(cm)


# ------------------------------------------------ LSTM ----------------------------------------------------------------
'''
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense, SpatialDropout1D
from tensorflow.keras.callbacks import EarlyStopping
from sklearn.model_selection import train_test_split
import seaborn as sns
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.metrics import classification_report


MAX_NB_WORDS = 50000
MAX_SEQUENCE_LENGTH = 250
EMBEDDING_DIM = 100

tokenizer = Tokenizer(num_words=MAX_NB_WORDS, filters='!"#$%&()*+,-./:;<=>?@[\]^_`{|}~', lower=True)
tokenizer.fit_on_texts(data['tidy_tweet'].values)
word_index = tokenizer.word_index
print('there are %s different words in total' % len(word_index))

X = tokenizer.texts_to_sequences(data['tidy_tweet'].values)
X = pad_sequences(X, maxlen=MAX_SEQUENCE_LENGTH)
Y = pd.get_dummies(data['SA']).values

print(X.shape)
print(Y.shape)

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.20, random_state=42)
print(X_train.shape, Y_train.shape)
print(X_test.shape, Y_test.shape)

# build model
model = Sequential()
model.add(Embedding(MAX_NB_WORDS, EMBEDDING_DIM, input_length=X.shape[1]))
model.add(SpatialDropout1D(0.2))
model.add(LSTM(50, dropout=0.2, recurrent_dropout=0.2))
model.add(Dense(3, activation='softmax'))
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
print(model.summary())

# train
epochs = 5
batch_size = 64
history = model.fit(X_train, Y_train, epochs=epochs, batch_size=batch_size, validation_split=0.1,
                    callbacks=[EarlyStopping(monitor='val_loss', patience=3, min_delta=0.0001)])

plt.title('Loss')
plt.plot(history.history['loss'], label='train')
plt.plot(history.history['val_loss'], label='test')
plt.legend()
plt.show()

plt.title('Accuracy')
plt.plot(history.history['acc'], label='train')
plt.plot(history.history['val_acc'], label='test')
plt.legend()
plt.show()

y_pred = model.predict(X_test)
y_pred = y_pred.argmax(axis=1)
Y_test = Y_test.argmax(axis=1)

# confusion matrix

conf_mat = confusion_matrix(Y_test, y_pred)
fig, ax = plt.subplots(figsize=(10, 8))
sns.heatmap(conf_mat, annot=True, fmt='d')
plt.ylabel('real', fontsize=18)
plt.xlabel('predict', fontsize=18)
plt.show()

print('prediction accuracy %s' % accuracy_score(y_pred, Y_test))
print(classification_report(Y_test, y_pred))
'''

